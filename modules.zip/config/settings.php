<?php
define('BASE_URL', 'https://joshiconsultants.in/erp/public/');
